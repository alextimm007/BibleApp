

// create a users class
public class Users{
    
    private String field1;
    private String field2;
    
    public Users(String field1,String field2){
        this.field1 = field1;
        this.field2 = field2;
    }
    
    public String getField1(){
        return this.field1;
    }
    
    public String getField2(){
        return this.field2;
    }
}
