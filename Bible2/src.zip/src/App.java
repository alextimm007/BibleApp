import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class App {

	Connection con;
	ResultSet rs = null;
	PreparedStatement pst = null;
	private JFrame frame;
	private JTextField textFieldVerse;
	private JButton btnSearch;
	private JLabel lblDisplayVerse, lblError;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App window = new App();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public App() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 550, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textFieldVerse = new JTextField();
		textFieldVerse.setBounds(10, 50, 75, 30);
		frame.getContentPane().add(textFieldVerse);
		textFieldVerse.setColumns(10);
		
		lblDisplayVerse = new JLabel();
		lblDisplayVerse.setBounds(120, 50, 400, 80);
		frame.getContentPane().add(lblDisplayVerse);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fetch();
			}
		});
		btnSearch.setBounds(10, 100, 75, 30);
		frame.getContentPane().add(btnSearch);
		
		lblError = new JLabel();
		lblError.setBounds(120, 140, 100, 20);
		frame.getContentPane().add(lblError);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnNewTable = new JMenu("Tabs");
		menuBar.add(mnNewTable);
		
		JMenuItem mntmCreateNewTab = new JMenuItem("Create New Tab");
		mntmCreateNewTab.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		mnNewTable.add(mntmCreateNewTab);
		
		JMenuItem mntmDeleteTab = new JMenuItem("Delete Tab");
		mnNewTable.add(mntmDeleteTab);
	}
	
	public void fetch() {
		try {
			String txtFld = textFieldVerse.getText().toLowerCase();
			con = DriverManager.getConnection("jdbc:sqlite:C:\\\\Eclipse\\\\Programs\\\\Bible2\\\\BibleDB.db");
			String q = "SELECT field2 "
					+ "FROM Bible "
					+ "WHERE field1 like '"+txtFld+"' ";	
			pst = con.prepareStatement(q);
			rs = pst.executeQuery();
			String str = rs.getString("field2");
			
			lblDisplayVerse.setText("<html> "+str+"</html>");		}
		catch(Exception e) {
			lblError.setText("No Such Result");
		}
	}
}
